<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>View Users</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

    <body>
        <div class="users">
            <h1>Users</h1>
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary">Create</a> <!-- Create button -->

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td>
                            <a href="<?php echo e(url('user/edit/'.$user->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                        </td>
                        <td>
                            <a href="<?php echo e(url('user/delete/'.$user->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                        </td>
                    </tr>
                </div>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </body>
</html> <?php /**PATH C:\Users\abram\Downloads\CS127 LAB\2 laravel\sampleLaravel\resources\views/users/view.blade.php ENDPATH**/ ?>