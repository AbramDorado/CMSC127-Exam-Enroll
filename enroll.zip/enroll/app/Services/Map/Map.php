<?php

namespace App\Services\Map;

class Map
{
    public function findAddress(string $address) {
        return [];
    }
}
