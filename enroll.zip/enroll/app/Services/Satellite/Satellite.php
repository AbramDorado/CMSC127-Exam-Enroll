<?php

namespace App\Services\Satellite;

class Satellite
{
    public function pinpoint(array $info) {
        return [123, 123];
    }
}
